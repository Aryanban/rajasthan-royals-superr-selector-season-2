All Super Smash match data in CSV format
========================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All Super Smash matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.9.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2026-01-31 - club - SSM - male - 1499659 - Canterbury vs Northern Districts
2026-01-31 - club - SSM - female - 1499691 - Auckland vs Wellington
2026-01-30 - club - SSM - male - 1499658 - Auckland vs Canterbury
2026-01-30 - club - SSM - female - 1499690 - Northern Districts vs Auckland
2026-01-26 - club - SSM - male - 1499657 - Auckland vs Central Districts
2026-01-26 - club - SSM - female - 1499689 - Central Districts vs Auckland
2026-01-25 - club - SSM - male - 1499656 - Northern Districts vs Canterbury
2026-01-25 - club - SSM - female - 1499688 - Northern Districts vs Canterbury
2026-01-24 - club - SSM - male - 1499655 - Otago vs Central Districts
2026-01-24 - club - SSM - female - 1499687 - Central Districts vs Otago
2026-01-23 - club - SSM - male - 1499654 - Wellington vs Canterbury
2026-01-23 - club - SSM - female - 1499686 - Wellington vs Canterbury
2026-01-22 - club - SSM - male - 1499653 - Northern Districts vs Auckland
2026-01-22 - club - SSM - female - 1499685 - Auckland vs Northern Districts
2026-01-21 - club - SSM - female - 1499684 - Otago vs Canterbury
2026-01-19 - club - SSM - male - 1499650 - Wellington vs Canterbury
2026-01-19 - club - SSM - female - 1499682 - Wellington vs Canterbury
2026-01-18 - club - SSM - male - 1499649 - Northern Districts vs Otago
2026-01-18 - club - SSM - female - 1499681 - Otago vs Northern Districts
2026-01-16 - club - SSM - male - 1499648 - Central Districts vs Auckland
2026-01-16 - club - SSM - female - 1499680 - Central Districts vs Auckland
2026-01-15 - club - SSM - male - 1499647 - Wellington vs Otago
2026-01-15 - club - SSM - female - 1499679 - Wellington vs Otago
2026-01-14 - club - SSM - male - 1499646 - Canterbury vs Auckland
2026-01-14 - club - SSM - female - 1499678 - Canterbury vs Auckland
2026-01-13 - club - SSM - male - 1499645 - Central Districts vs Northern Districts
2026-01-13 - club - SSM - female - 1499677 - Northern Districts vs Central Districts
2026-01-12 - club - SSM - male - 1499644 - Otago vs Auckland
2026-01-12 - club - SSM - female - 1499676 - Auckland vs Otago
2026-01-11 - club - SSM - male - 1499643 - Wellington vs Northern Districts
2026-01-11 - club - SSM - female - 1499675 - Wellington vs Northern Districts
2026-01-10 - club - SSM - male - 1499642 - Canterbury vs Auckland
2026-01-10 - club - SSM - female - 1499674 - Auckland vs Canterbury
2026-01-09 - club - SSM - male - 1499641 - Wellington vs Otago
2026-01-09 - club - SSM - female - 1499673 - Otago vs Wellington
2026-01-08 - club - SSM - male - 1499640 - Northern Districts vs Canterbury
2026-01-08 - club - SSM - female - 1499672 - Northern Districts vs Canterbury
2026-01-07 - club - SSM - male - 1499639 - Central Districts vs Wellington
2026-01-07 - club - SSM - female - 1499671 - Central Districts vs Wellington
2026-01-06 - club - SSM - male - 1499638 - Auckland vs Otago
2026-01-06 - club - SSM - female - 1499670 - Auckland vs Otago
2026-01-04 - club - SSM - male - 1499637 - Otago vs Northern Districts
2026-01-04 - club - SSM - female - 1499669 - Northern Districts vs Otago
2026-01-03 - club - SSM - male - 1499636 - Central Districts vs Canterbury
2026-01-03 - club - SSM - female - 1499668 - Central Districts vs Canterbury
2026-01-02 - club - SSM - female - 1499667 - Wellington vs Auckland
2026-01-01 - club - SSM - male - 1499634 - Canterbury vs Central Districts
2026-01-01 - club - SSM - female - 1499666 - Canterbury vs Central Districts
2025-12-31 - club - SSM - male - 1499633 - Wellington vs Northern Districts
2025-12-31 - club - SSM - female - 1499665 - Wellington vs Northern Districts
2025-12-30 - club - SSM - male - 1499632 - Otago vs Central Districts
2025-12-30 - club - SSM - female - 1499664 - Central Districts vs Otago
2025-12-29 - club - SSM - male - 1499631 - Wellington vs Auckland
2025-12-29 - club - SSM - female - 1499663 - Wellington vs Auckland
2025-12-28 - club - SSM - male - 1499630 - Canterbury vs Otago
2025-12-28 - club - SSM - female - 1499662 - Canterbury vs Otago
2025-12-27 - club - SSM - male - 1499629 - Central Districts vs Wellington
2025-12-27 - club - SSM - female - 1499661 - Wellington vs Central Districts
2025-12-26 - club - SSM - male - 1499628 - Auckland vs Northern Districts
2025-12-26 - club - SSM - female - 1499660 - Auckland vs Northern Districts
2025-02-02 - club - SSM - male - 1452620 - Canterbury vs Central Districts
2025-02-02 - club - SSM - female - 1452588 - Wellington vs Otago
2025-02-01 - club - SSM - male - 1452619 - Northern Districts vs Canterbury
2025-02-01 - club - SSM - female - 1452587 - Wellington vs Northern Districts
2025-01-30 - club - SSM - female - 1452586 - Wellington vs Northern Districts
2025-01-29 - club - SSM - male - 1452617 - Auckland vs Central Districts
2025-01-29 - club - SSM - female - 1452585 - Auckland vs Central Districts
2025-01-28 - club - SSM - male - 1452616 - Canterbury vs Northern Districts
2025-01-28 - club - SSM - female - 1452584 - Canterbury vs Northern Districts
2025-01-27 - club - SSM - male - 1452615 - Auckland vs Wellington
2025-01-27 - club - SSM - female - 1452583 - Auckland vs Wellington
2025-01-26 - club - SSM - male - 1452614 - Central Districts vs Canterbury
2025-01-26 - club - SSM - female - 1452582 - Canterbury vs Central Districts
2025-01-25 - club - SSM - male - 1452613 - Otago vs Northern Districts
2025-01-25 - club - SSM - female - 1452581 - Northern Districts vs Otago
2025-01-24 - club - SSM - male - 1452612 - Wellington vs Canterbury
2025-01-24 - club - SSM - female - 1452580 - Canterbury vs Wellington
2025-01-23 - club - SSM - male - 1452611 - Auckland vs Otago
2025-01-23 - club - SSM - female - 1452579 - Auckland vs Otago
2025-01-22 - club - SSM - male - 1452610 - Canterbury vs Wellington
2025-01-22 - club - SSM - female - 1452578 - Wellington vs Canterbury
2025-01-20 - club - SSM - male - 1452608 - Auckland vs Wellington
2025-01-20 - club - SSM - female - 1452576 - Wellington vs Auckland
2025-01-19 - club - SSM - male - 1452607 - Canterbury vs Northern Districts
2025-01-19 - club - SSM - female - 1452575 - Northern Districts vs Canterbury
2025-01-18 - club - SSM - male - 1452606 - Wellington vs Otago
2025-01-18 - club - SSM - female - 1452574 - Wellington vs Otago
2025-01-17 - club - SSM - male - 1452605 - Central Districts vs Canterbury
2025-01-17 - club - SSM - female - 1452573 - Canterbury vs Central Districts
2025-01-16 - club - SSM - male - 1452604 - Northern Districts vs Otago
2025-01-16 - club - SSM - female - 1452572 - Otago vs Northern Districts
2025-01-15 - club - SSM - male - 1452603 - Auckland vs Central Districts
2025-01-15 - club - SSM - female - 1452571 - Auckland vs Central Districts
2025-01-14 - club - SSM - male - 1452602 - Otago vs Wellington
2025-01-14 - club - SSM - female - 1452570 - Wellington vs Otago
2025-01-13 - club - SSM - male - 1452601 - Auckland vs Northern Districts
2025-01-13 - club - SSM - female - 1452569 - Northern Districts vs Auckland
2025-01-12 - club - SSM - male - 1452600 - Central Districts vs Otago
2025-01-12 - club - SSM - female - 1452568 - Central Districts vs Otago
2025-01-10 - club - SSM - male - 1452599 - Canterbury vs Auckland
2025-01-10 - club - SSM - female - 1452567 - Auckland vs Canterbury
2025-01-09 - club - SSM - male - 1452598 - Wellington vs Central Districts
2025-01-09 - club - SSM - female - 1452566 - Central Districts vs Wellington
2025-01-07 - club - SSM - male - 1452597 - Canterbury vs Otago
2025-01-07 - club - SSM - female - 1452565 - Otago vs Canterbury
2025-01-06 - club - SSM - male - 1452596 - Central Districts vs Northern Districts
2025-01-06 - club - SSM - female - 1452564 - Central Districts vs Northern Districts
2025-01-04 - club - SSM - male - 1452595 - Wellington vs Central Districts
2025-01-04 - club - SSM - female - 1452563 - Wellington vs Central Districts
2025-01-03 - club - SSM - male - 1452594 - Auckland vs Canterbury
2025-01-03 - club - SSM - female - 1452562 - Auckland vs Canterbury
2025-01-01 - club - SSM - male - 1452593 - Wellington vs Northern Districts
2025-01-01 - club - SSM - female - 1452561 - Wellington vs Northern Districts
2024-12-31 - club - SSM - male - 1452592 - Otago vs Central Districts
2024-12-31 - club - SSM - female - 1452560 - Central Districts vs Otago
2024-12-29 - club - SSM - male - 1452591 - Auckland vs Otago
2024-12-29 - club - SSM - female - 1452559 - Auckland vs Otago
2024-12-27 - club - SSM - male - 1452590 - Otago vs Canterbury
2024-12-27 - club - SSM - female - 1452558 - Canterbury vs Otago
2024-12-26 - club - SSM - female - 1452557 - Northern Districts vs Auckland
2024-01-28 - club - SSM - male - 1409505 - Canterbury vs Auckland
2024-01-28 - club - SSM - female - 1409537 - Wellington vs Central Districts
2024-01-26 - club - SSM - male - 1409504 - Wellington vs Canterbury
2024-01-26 - club - SSM - female - 1409536 - Central Districts vs Northern Districts
2024-01-23 - club - SSM - male - 1409503 - Northern Districts vs Otago
2024-01-23 - club - SSM - female - 1409535 - Northern Districts vs Otago
2024-01-22 - club - SSM - male - 1409502 - Canterbury vs Wellington
2024-01-22 - club - SSM - female - 1409534 - Canterbury vs Wellington
2024-01-20 - club - SSM - male - 1409501 - Auckland vs Northern Districts
2024-01-20 - club - SSM - female - 1409533 - Northern Districts vs Auckland
2024-01-19 - club - SSM - male - 1409500 - Otago vs Central Districts
2024-01-19 - club - SSM - female - 1409532 - Central Districts vs Otago
2024-01-18 - club - SSM - male - 1409499 - Canterbury vs Northern Districts
2024-01-18 - club - SSM - female - 1409531 - Northern Districts vs Canterbury
2024-01-16 - club - SSM - male - 1409498 - Central Districts vs Auckland
2024-01-16 - club - SSM - female - 1409530 - Central Districts vs Auckland
2024-01-15 - club - SSM - male - 1409497 - Wellington vs Northern Districts
2024-01-15 - club - SSM - female - 1409529 - Northern Districts vs Wellington
2024-01-14 - club - SSM - male - 1409496 - Otago vs Auckland
2024-01-14 - club - SSM - female - 1409528 - Auckland vs Otago
2024-01-13 - club - SSM - male - 1409495 - Wellington vs Central Districts
2024-01-13 - club - SSM - female - 1409527 - Wellington vs Central Districts
2024-01-12 - club - SSM - male - 1409494 - Northern Districts vs Auckland
2024-01-12 - club - SSM - female - 1409526 - Northern Districts vs Auckland
2024-01-11 - club - SSM - male - 1409493 - Wellington vs Canterbury
2024-01-11 - club - SSM - female - 1409525 - Wellington vs Canterbury
2024-01-10 - club - SSM - male - 1409492 - Central Districts vs Otago
2024-01-10 - club - SSM - female - 1409524 - Central Districts vs Otago
2024-01-09 - club - SSM - male - 1409491 - Canterbury vs Northern Districts
2024-01-09 - club - SSM - female - 1409523 - Northern Districts vs Canterbury
2024-01-08 - club - SSM - male - 1409490 - Central Districts vs Wellington
2024-01-08 - club - SSM - female - 1409522 - Central Districts vs Wellington
2024-01-07 - club - SSM - male - 1409489 - Canterbury vs Auckland
2024-01-07 - club - SSM - female - 1409521 - Canterbury vs Auckland
2024-01-06 - club - SSM - male - 1409488 - Northern Districts vs Otago
2024-01-06 - club - SSM - female - 1409520 - Northern Districts vs Otago
2024-01-05 - club - SSM - male - 1409487 - Central Districts vs Canterbury
2024-01-04 - club - SSM - male - 1409486 - Auckland vs Wellington
2024-01-04 - club - SSM - female - 1409518 - Auckland vs Wellington
2024-01-03 - club - SSM - male - 1409485 - Otago vs Canterbury
2024-01-03 - club - SSM - female - 1409517 - Canterbury vs Otago
2024-01-02 - club - SSM - male - 1409484 - Wellington vs Northern Districts
2024-01-02 - club - SSM - female - 1409516 - Wellington vs Northern Districts
2024-01-01 - club - SSM - male - 1409483 - Auckland vs Otago
2024-01-01 - club - SSM - female - 1409515 - Otago vs Auckland
2023-12-30 - club - SSM - male - 1409482 - Canterbury vs Central Districts
2023-12-30 - club - SSM - female - 1409514 - Central Districts vs Canterbury
2023-12-28 - club - SSM - male - 1409480 - Otago vs Wellington
2023-12-28 - club - SSM - female - 1409512 - Wellington vs Otago
2023-12-27 - club - SSM - male - 1409479 - Central Districts vs Northern Districts
2023-12-27 - club - SSM - female - 1409511 - Central Districts vs Northern Districts
2023-12-26 - club - SSM - male - 1409478 - Canterbury vs Otago
2023-12-26 - club - SSM - female - 1409510 - Canterbury vs Otago
2023-12-22 - club - SSM - male - 1409476 - Northern Districts vs Central Districts
2023-12-22 - club - SSM - female - 1409508 - Northern Districts vs Central Districts
2023-12-21 - club - SSM - male - 1409475 - Wellington vs Otago
2023-12-21 - club - SSM - female - 1409507 - Wellington vs Otago
2023-12-19 - club - SSM - male - 1409474 - Auckland vs Canterbury
2023-12-19 - club - SSM - female - 1409506 - Canterbury vs Auckland
2023-02-11 - club - SSM - male - 1341225 - Canterbury vs Northern Districts
2023-02-11 - club - SSM - female - 1341257 - Canterbury vs Wellington
2023-02-09 - club - SSM - male - 1341224 - Northern Districts vs Otago
2023-02-09 - club - SSM - female - 1341256 - Otago vs Canterbury
2023-02-06 - club - SSM - male - 1341223 - Otago vs Canterbury
2023-02-06 - club - SSM - female - 1341255 - Canterbury vs Otago
2023-02-05 - club - SSM - male - 1341222 - Auckland vs Wellington
2023-02-05 - club - SSM - female - 1341254 - Auckland vs Wellington
2023-02-04 - club - SSM - male - 1341221 - Canterbury vs Otago
2023-02-04 - club - SSM - female - 1341253 - Canterbury vs Otago
2023-02-03 - club - SSM - male - 1341220 - Central Districts vs Northern Districts
2023-02-03 - club - SSM - female - 1341252 - Northern Districts vs Central Districts
2023-01-29 - club - SSM - male - 1341218 - Central Districts vs Otago
2023-01-29 - club - SSM - female - 1341250 - Central Districts vs Otago
2023-01-27 - club - SSM - male - 1341216 - Canterbury vs Central Districts
2023-01-27 - club - SSM - female - 1341248 - Canterbury vs Central Districts
2023-01-23 - club - SSM - male - 1341215 - Wellington vs Canterbury
2023-01-23 - club - SSM - female - 1341247 - Wellington vs Canterbury
2023-01-22 - club - SSM - male - 1341214 - Northern Districts vs Auckland
2023-01-22 - club - SSM - female - 1341246 - Auckland vs Northern Districts
2023-01-21 - club - SSM - male - 1341213 - Otago vs Central Districts
2023-01-21 - club - SSM - female - 1341245 - Central Districts vs Otago
2023-01-20 - club - SSM - male - 1341212 - Wellington vs Auckland
2023-01-20 - club - SSM - female - 1341244 - Wellington vs Auckland
2023-01-15 - club - SSM - male - 1341211 - Wellington vs Otago
2023-01-15 - club - SSM - female - 1341243 - Otago vs Wellington
2023-01-14 - club - SSM - male - 1341210 - Auckland vs Central Districts
2023-01-14 - club - SSM - female - 1341242 - Central Districts vs Auckland
2023-01-13 - club - SSM - male - 1341209 - Canterbury vs Northern Districts
2023-01-13 - club - SSM - female - 1341241 - Northern Districts vs Canterbury
2023-01-08 - club - SSM - male - 1341208 - Auckland vs Canterbury
2023-01-08 - club - SSM - female - 1341240 - Canterbury vs Auckland
2023-01-07 - club - SSM - female - 1341239 - Central Districts vs Wellington
2023-01-06 - club - SSM - female - 1341238 - Northern Districts vs Otago
2023-01-05 - club - SSM - male - 1341205 - Auckland vs Central Districts
2023-01-05 - club - SSM - female - 1341237 - Auckland vs Central Districts
2023-01-04 - club - SSM - male - 1341204 - Wellington vs Northern Districts
2023-01-04 - club - SSM - female - 1341236 - Wellington vs Northern Districts
2023-01-02 - club - SSM - male - 1341203 - Otago vs Auckland
2023-01-02 - club - SSM - female - 1341235 - Otago vs Auckland
2023-01-01 - club - SSM - male - 1341202 - Canterbury vs Wellington
2023-01-01 - club - SSM - female - 1341234 - Wellington vs Canterbury
2022-12-31 - club - SSM - male - 1341201 - Northern Districts vs Central Districts
2022-12-31 - club - SSM - female - 1341233 - Northern Districts vs Central Districts
2022-12-30 - club - SSM - male - 1341200 - Canterbury vs Central Districts
2022-12-30 - club - SSM - female - 1341232 - Central Districts vs Canterbury
2022-12-29 - club - SSM - male - 1341199 - Otago vs Auckland
2022-12-29 - club - SSM - female - 1341231 - Otago vs Auckland
2022-12-28 - club - SSM - male - 1341198 - Otago vs Northern Districts
2022-12-28 - club - SSM - female - 1341230 - Otago vs Northern Districts
2022-12-27 - club - SSM - male - 1341197 - Wellington vs Central Districts
2022-12-27 - club - SSM - female - 1341229 - Wellington vs Central Districts
2022-12-26 - club - SSM - male - 1341196 - Canterbury vs Auckland
2022-12-26 - club - SSM - female - 1341228 - Auckland vs Canterbury
2022-12-24 - club - SSM - male - 1341195 - Wellington vs Otago
2022-12-24 - club - SSM - female - 1341227 - Wellington vs Otago
2022-12-23 - club - SSM - male - 1341194 - Northern Districts vs Canterbury
2022-12-23 - club - SSM - female - 1341226 - Canterbury vs Northern Districts
2022-01-29 - club - SSM - male - 1289634 - Northern Districts vs Canterbury
2022-01-29 - club - SSM - female - 1290661 - Wellington vs Otago
2022-01-27 - club - SSM - male - 1289633 - Wellington vs Canterbury
2022-01-27 - club - SSM - female - 1290660 - Otago vs Auckland
2022-01-24 - club - SSM - male - 1289632 - Wellington vs Northern Districts
2022-01-24 - club - SSM - female - 1290659 - Wellington vs Northern Districts
2022-01-23 - club - SSM - male - 1289631 - Otago vs Canterbury
2022-01-23 - club - SSM - female - 1290658 - Canterbury vs Otago
2022-01-22 - club - SSM - male - 1289630 - Central Districts vs Auckland
2022-01-22 - club - SSM - female - 1290657 - Central Districts vs Auckland
2022-01-21 - club - SSM - male - 1289629 - Canterbury vs Northern Districts
2022-01-21 - club - SSM - female - 1290656 - Canterbury vs Northern Districts
2022-01-20 - club - SSM - male - 1289610 - Auckland vs Wellington
2022-01-20 - club - SSM - female - 1290637 - Auckland vs Wellington
2022-01-18 - club - SSM - male - 1289607 - Canterbury vs Auckland
2022-01-18 - club - SSM - female - 1290634 - Auckland vs Canterbury
2022-01-16 - club - SSM - male - 1289628 - Wellington vs Northern Districts
2022-01-16 - club - SSM - female - 1290655 - Northern Districts vs Wellington
2022-01-15 - club - SSM - male - 1289627 - Otago vs Auckland
2022-01-15 - club - SSM - female - 1290654 - Auckland vs Otago
2022-01-14 - club - SSM - male - 1289626 - Northern Districts vs Central Districts
2022-01-14 - club - SSM - female - 1290653 - Northern Districts vs Central Districts
2022-01-08 - club - SSM - male - 1289625 - Central Districts vs Wellington
2022-01-08 - club - SSM - female - 1290652 - Central Districts vs Wellington
2022-01-07 - club - SSM - male - 1289624 - Auckland vs Canterbury
2022-01-07 - club - SSM - female - 1290651 - Auckland vs Canterbury
2022-01-06 - club - SSM - male - 1289623 - Otago vs Wellington
2022-01-06 - club - SSM - female - 1290650 - Wellington vs Otago
2021-12-31 - club - SSM - male - 1289622 - Central Districts vs Canterbury
2021-12-31 - club - SSM - female - 1290649 - Central Districts vs Canterbury
2021-12-30 - club - SSM - male - 1289621 - Central Districts vs Northern Districts
2021-12-30 - club - SSM - female - 1290648 - Northern Districts vs Central Districts
2021-12-29 - club - SSM - male - 1289620 - Otago vs Auckland
2021-12-29 - club - SSM - female - 1290647 - Otago vs Auckland
2021-12-28 - club - SSM - male - 1289619 - Otago vs Wellington
2021-12-28 - club - SSM - female - 1290646 - Wellington vs Otago
2021-12-27 - club - SSM - male - 1289618 - Central Districts vs Auckland
2021-12-27 - club - SSM - female - 1290645 - Central Districts vs Auckland
2021-12-26 - club - SSM - male - 1289617 - Canterbury vs Otago
2021-12-26 - club - SSM - female - 1290644 - Otago vs Canterbury
2021-12-24 - club - SSM - male - 1289616 - Auckland vs Wellington
2021-12-24 - club - SSM - female - 1290643 - Wellington vs Auckland
2021-12-23 - club - SSM - male - 1289615 - Canterbury vs Northern Districts
2021-12-23 - club - SSM - female - 1290642 - Canterbury vs Northern Districts
2021-12-20 - club - SSM - male - 1289604 - Auckland vs Northern Districts
2021-12-20 - club - SSM - female - 1290631 - Northern Districts vs Auckland
2021-12-19 - club - SSM - male - 1289614 - Wellington vs Canterbury
2021-12-19 - club - SSM - female - 1290641 - Wellington vs Canterbury
2021-12-18 - club - SSM - male - 1289613 - Central Districts vs Otago
2021-12-18 - club - SSM - female - 1290640 - Central Districts vs Otago
2021-12-17 - club - SSM - male - 1289612 - Auckland vs Northern Districts
2021-12-17 - club - SSM - female - 1290639 - Auckland vs Northern Districts
2021-12-12 - club - SSM - male - 1289611 - Northern Districts vs Otago
2021-12-12 - club - SSM - female - 1290638 - Northern Districts vs Otago
2021-12-10 - club - SSM - male - 1289609 - Canterbury vs Central Districts
2021-12-10 - club - SSM - female - 1290636 - Central Districts vs Canterbury
2021-12-05 - club - SSM - male - 1289608 - Central Districts vs Wellington
2021-12-05 - club - SSM - female - 1290635 - Wellington vs Central Districts
2021-12-03 - club - SSM - male - 1289606 - Northern Districts vs Otago
2021-12-03 - club - SSM - female - 1290633 - Otago vs Northern Districts
2021-11-28 - club - SSM - male - 1289605 - Otago vs Central Districts
2021-11-28 - club - SSM - female - 1290632 - Otago vs Central Districts
2021-11-26 - club - SSM - male - 1289603 - Wellington vs Canterbury
2021-11-26 - club - SSM - female - 1290630 - Wellington vs Canterbury
2021-02-13 - club - SSM - male - 1234028 - Canterbury vs Wellington
2021-02-13 - club - SSM - female - 1234060 - Wellington vs Canterbury
2021-02-11 - club - SSM - male - 1234027 - Central Districts vs Canterbury
2021-02-11 - club - SSM - female - 1234059 - Wellington vs Auckland
2021-02-07 - club - SSM - male - 1234026 - Wellington vs Auckland
2021-02-07 - club - SSM - female - 1234058 - Auckland vs Wellington
2021-02-06 - club - SSM - male - 1234025 - Northern Districts vs Otago
2021-02-06 - club - SSM - female - 1234057 - Otago vs Northern Districts
2021-02-05 - club - SSM - male - 1234024 - Central Districts vs Canterbury
2021-02-05 - club - SSM - female - 1234056 - Canterbury vs Central Districts
2021-02-01 - club - SSM - male - 1234023 - Auckland vs Otago
2021-02-01 - club - SSM - female - 1234055 - Auckland vs Otago
2021-01-31 - club - SSM - male - 1234022 - Central Districts vs Wellington
2021-01-31 - club - SSM - female - 1234054 - Wellington vs Central Districts
2021-01-30 - club - SSM - male - 1234021 - Otago vs Canterbury
2021-01-30 - club - SSM - female - 1234053 - Canterbury vs Otago
2021-01-29 - club - SSM - male - 1234020 - Auckland vs Northern Districts
2021-01-29 - club - SSM - female - 1234052 - Northern Districts vs Auckland
2021-01-25 - club - SSM - male - 1234019 - Canterbury vs Wellington
2021-01-25 - club - SSM - female - 1234051 - Wellington vs Canterbury
2021-01-24 - club - SSM - male - 1234018 - Otago vs Wellington
2021-01-24 - club - SSM - female - 1234050 - Wellington vs Otago
2021-01-23 - club - SSM - male - 1234017 - Auckland vs Central Districts
2021-01-23 - club - SSM - female - 1234049 - Auckland vs Central Districts
2021-01-21 - club - SSM - male - 1234016 - Canterbury vs Northern Districts
2021-01-21 - club - SSM - female - 1234048 - Northern Districts vs Canterbury
2021-01-18 - club - SSM - male - 1234015 - Otago vs Central Districts
2021-01-18 - club - SSM - female - 1234047 - Central Districts vs Otago
2021-01-17 - club - SSM - male - 1234014 - Auckland vs Northern Districts
2021-01-17 - club - SSM - female - 1234046 - Northern Districts vs Auckland
2021-01-16 - club - SSM - male - 1234013 - Wellington vs Canterbury
2021-01-16 - club - SSM - female - 1234045 - Canterbury vs Wellington
2021-01-15 - club - SSM - male - 1234012 - Northern Districts vs Canterbury
2021-01-15 - club - SSM - female - 1234044 - Canterbury vs Northern Districts
2021-01-14 - club - SSM - male - 1234011 - Otago vs Wellington
2021-01-14 - club - SSM - female - 1234043 - Otago vs Wellington
2021-01-11 - club - SSM - male - 1234010 - Canterbury vs Auckland
2021-01-11 - club - SSM - female - 1234042 - Auckland vs Canterbury
2021-01-10 - club - SSM - male - 1234009 - Central Districts vs Canterbury
2021-01-10 - club - SSM - female - 1234041 - Central Districts vs Canterbury
2021-01-09 - club - SSM - male - 1234008 - Wellington vs Northern Districts
2021-01-09 - club - SSM - female - 1234040 - Northern Districts vs Wellington
2021-01-08 - club - SSM - male - 1234007 - Central Districts vs Otago
2021-01-08 - club - SSM - female - 1234039 - Central Districts vs Otago
2021-01-04 - club - SSM - male - 1234006 - Central Districts vs Northern Districts
2021-01-04 - club - SSM - female - 1234038 - Central Districts vs Northern Districts
2021-01-03 - club - SSM - male - 1234005 - Auckland vs Canterbury
2021-01-03 - club - SSM - female - 1234037 - Canterbury vs Auckland
2021-01-02 - club - SSM - male - 1234004 - Northern Districts vs Otago
2021-01-02 - club - SSM - female - 1234036 - Northern Districts vs Otago
2021-01-01 - club - SSM - male - 1234003 - Northern Districts vs Wellington
2021-01-01 - club - SSM - female - 1234035 - Wellington vs Northern Districts
2020-12-31 - club - SSM - male - 1234002 - Central Districts vs Auckland
2020-12-31 - club - SSM - female - 1234034 - Auckland vs Central Districts
2020-12-30 - club - SSM - male - 1234001 - Central Districts vs Northern Districts
2020-12-30 - club - SSM - female - 1234033 - Northern Districts vs Central Districts
2020-12-29 - club - SSM - male - 1234000 - Canterbury vs Otago
2020-12-29 - club - SSM - female - 1234032 - Otago vs Canterbury
2020-12-28 - club - SSM - male - 1233999 - Otago vs Auckland
2020-12-28 - club - SSM - female - 1234031 - Auckland vs Otago
2020-12-27 - club - SSM - male - 1233998 - Wellington vs Central Districts
2020-12-27 - club - SSM - female - 1234030 - Central Districts vs Wellington
2020-12-24 - club - SSM - male - 1233997 - Auckland vs Wellington
2020-12-24 - club - SSM - female - 1234029 - Auckland vs Wellington
2020-01-19 - club - SSM - male - 1197772 - Wellington vs Auckland
2020-01-19 - club - SSM - female - 1197804 - Wellington vs Auckland
2020-01-17 - club - SSM - male - 1197771 - Otago vs Auckland
2020-01-16 - club - SSM - female - 1197803 - Otago vs Auckland
2020-01-14 - club - SSM - male - 1197770 - Otago vs Canterbury
2020-01-14 - club - SSM - female - 1197802 - Otago vs Canterbury
2020-01-12 - club - SSM - male - 1197769 - Wellington vs Auckland
2020-01-12 - club - SSM - male - 1197768 - Canterbury vs Northern Districts
2020-01-12 - club - SSM - female - 1197801 - Northern Districts vs Canterbury
2020-01-12 - club - SSM - female - 1197800 - Auckland vs Wellington
2020-01-11 - club - SSM - male - 1197767 - Central Districts vs Otago
2020-01-11 - club - SSM - female - 1197799 - Central Districts vs Otago
2020-01-10 - club - SSM - male - 1197766 - Auckland vs Northern Districts
2020-01-10 - club - SSM - female - 1197798 - Auckland vs Northern Districts
2020-01-09 - club - SSM - male - 1197765 - Canterbury vs Wellington
2020-01-09 - club - SSM - female - 1197797 - Canterbury vs Wellington
2020-01-07 - club - SSM - male - 1197764 - Central Districts vs Canterbury
2020-01-06 - club - SSM - male - 1197763 - Otago vs Wellington
2020-01-05 - club - SSM - male - 1197762 - Northern Districts vs Canterbury
2020-01-05 - club - SSM - female - 1197796 - Northern Districts vs Canterbury
2020-01-04 - club - SSM - male - 1197761 - Central Districts vs Auckland
2020-01-04 - club - SSM - female - 1197795 - Central Districts vs Auckland
2020-01-03 - club - SSM - male - 1197760 - Wellington vs Northern Districts
2020-01-03 - club - SSM - female - 1197794 - Wellington vs Northern Districts
2020-01-02 - club - SSM - male - 1197759 - Otago vs Central Districts
2020-01-02 - club - SSM - female - 1197793 - Otago vs Central Districts
2020-01-01 - club - SSM - male - 1197758 - Wellington vs Northern Districts
2020-01-01 - club - SSM - male - 1197757 - Canterbury vs Auckland
2019-12-30 - club - SSM - male - 1197756 - Otago vs Canterbury
2019-12-30 - club - SSM - male - 1197755 - Auckland vs Wellington
2019-12-29 - club - SSM - male - 1197754 - Northern Districts vs Otago
2019-12-28 - club - SSM - male - 1197753 - Auckland vs Central Districts
2019-12-27 - club - SSM - male - 1197752 - Wellington vs Central Districts
2019-12-23 - club - SSM - male - 1197751 - Canterbury vs Central Districts
2019-12-22 - club - SSM - male - 1197750 - Northern Districts vs Auckland
2019-12-21 - club - SSM - male - 1197749 - Wellington vs Otago
2019-12-20 - club - SSM - male - 1197748 - Central Districts vs Northern Districts
2019-12-19 - club - SSM - male - 1197747 - Otago vs Auckland
2019-12-18 - club - SSM - male - 1197746 - Central Districts vs Wellington
2019-12-17 - club - SSM - male - 1197745 - Canterbury vs Auckland
2019-12-16 - club - SSM - male - 1197744 - Otago vs Northern Districts
2019-12-15 - club - SSM - male - 1197743 - Canterbury vs Wellington
2019-12-14 - club - SSM - male - 1197742 - Otago vs Auckland
2019-12-13 - club - SSM - male - 1197741 - Central Districts vs Northern Districts
2019-02-17 - club - SSM - male - 1160528 - Central Districts vs Northern Districts
2019-02-15 - club - SSM - male - 1160527 - Central Districts vs Auckland
2019-02-09 - club - SSM - male - 1160526 - Central Districts vs Auckland
2019-02-09 - club - SSM - male - 1160525 - Wellington vs Canterbury
2019-02-09 - club - SSM - male - 1160524 - Northern Districts vs Otago
2019-02-02 - club - SSM - male - 1160523 - Northern Districts vs Auckland
2019-02-02 - club - SSM - male - 1160522 - Canterbury vs Otago
2019-02-01 - club - SSM - male - 1160521 - Central Districts vs Wellington
2019-01-27 - club - SSM - male - 1160520 - Wellington vs Otago
2019-01-26 - club - SSM - male - 1160519 - Canterbury vs Auckland
2019-01-25 - club - SSM - male - 1160518 - Northern Districts vs Central Districts
2019-01-20 - club - SSM - male - 1160517 - Auckland vs Otago
2019-01-19 - club - SSM - male - 1160516 - Central Districts vs Canterbury
2019-01-18 - club - SSM - male - 1160515 - Wellington vs Auckland
2019-01-16 - club - SSM - male - 1160514 - Northern Districts vs Canterbury
2019-01-13 - club - SSM - male - 1160513 - Canterbury vs Central Districts
2019-01-13 - club - SSM - male - 1160512 - Auckland vs Otago
2019-01-12 - club - SSM - male - 1160511 - Northern Districts vs Wellington
2019-01-10 - club - SSM - male - 1160510 - Central Districts vs Otago
2019-01-06 - club - SSM - male - 1160508 - Wellington vs Canterbury
2019-01-06 - club - SSM - male - 1160506 - Northern Districts vs Auckland
2019-01-01 - club - SSM - male - 1160505 - Auckland vs Canterbury
2018-12-31 - club - SSM - male - 1160504 - Central Districts vs Wellington
2018-12-30 - club - SSM - male - 1160503 - Otago vs Northern Districts
2018-12-29 - club - SSM - male - 1160502 - Central Districts vs Auckland
2018-12-28 - club - SSM - male - 1160501 - Otago vs Wellington
2018-12-27 - club - SSM - male - 1160500 - Northern Districts vs Central Districts
2018-12-22 - club - SSM - male - 1160497 - Northern Districts vs Wellington
2018-01-20 - club - SSM - male - 1132902 - Central Districts vs Northern Districts
2018-01-17 - club - SSM - male - 1132901 - Central Districts vs Auckland
2018-01-14 - club - SSM - male - 1118563 - Auckland vs Otago
2018-01-14 - club - SSM - male - 1118562 - Central Districts vs Wellington
2018-01-14 - club - SSM - male - 1118561 - Canterbury vs Northern Districts
2018-01-12 - club - SSM - male - 1118560 - Central Districts vs Wellington
2018-01-10 - club - SSM - male - 1118559 - Canterbury vs Auckland
2018-01-09 - club - SSM - male - 1118558 - Central Districts vs Otago
2018-01-07 - club - SSM - male - 1118557 - Canterbury vs Wellington
2018-01-07 - club - SSM - male - 1118556 - Auckland vs Northern Districts
2018-01-06 - club - SSM - male - 1118555 - Central Districts vs Otago
2018-01-02 - club - SSM - male - 1118552 - Otago vs Northern Districts
2018-01-01 - club - SSM - male - 1118551 - Auckland vs Canterbury
2017-12-31 - club - SSM - male - 1118550 - Otago vs Wellington
2017-12-30 - club - SSM - male - 1118549 - Central Districts vs Northern Districts
2017-12-28 - club - SSM - male - 1118548 - Canterbury vs Wellington
2017-12-27 - club - SSM - male - 1118546 - Central Districts vs Northern Districts
2017-12-26 - club - SSM - male - 1118545 - Otago vs Canterbury
2017-12-24 - club - SSM - male - 1118543 - Wellington vs Auckland
2017-12-23 - club - SSM - male - 1118542 - Northern Districts vs Otago
2017-12-22 - club - SSM - male - 1118541 - Canterbury vs Central Districts
2017-12-20 - club - SSM - male - 1118540 - Northern Districts vs Wellington
2017-12-17 - club - SSM - male - 1118538 - Central Districts vs Canterbury
2017-12-16 - club - SSM - male - 1118537 - Northern Districts vs Auckland
2017-12-14 - club - SSM - male - 1118535 - Canterbury vs Otago
2017-12-13 - club - SSM - male - 1118534 - Auckland vs Central Districts
2014-01-18 - club - SSM - male - 665703 - Otago vs Northern Districts
2014-01-17 - club - SSM - male - 665701 - Northern Districts vs Canterbury
2014-01-03 - club - SSM - male - 665677 - Auckland vs Otago
2013-01-20 - club - SSM - male - 580784 - Wellington vs Otago

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk

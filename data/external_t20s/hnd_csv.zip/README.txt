All The Hundred match data in CSV format
========================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All The Hundred matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.9.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2026-08-16 - club - HND - male - 1521264 - Trent Rockets vs Manchester Super Giants
2026-08-16 - club - HND - female - 1521230 - Sunrisers Leeds vs Trent Rockets
2026-08-14 - club - HND - male - 1521263 - Manchester Super Giants vs Sunrisers Leeds
2026-08-14 - club - HND - female - 1521229 - Southern Brave vs Sunrisers Leeds
2026-08-12 - club - HND - male - 1521262 - MI London vs Birmingham Phoenix
2026-08-12 - club - HND - male - 1521261 - London Spirit vs Welsh Fire
2026-08-12 - club - HND - female - 1521228 - MI London vs Birmingham Phoenix
2026-08-12 - club - HND - female - 1521227 - Welsh Fire vs London Spirit
2026-08-11 - club - HND - male - 1521260 - Sunrisers Leeds vs Manchester Super Giants
2026-08-11 - club - HND - female - 1521226 - Sunrisers Leeds vs Manchester Super Giants
2026-08-10 - club - HND - male - 1521259 - Trent Rockets vs Southern Brave
2026-08-10 - club - HND - female - 1521225 - Southern Brave vs Trent Rockets
2026-08-09 - club - HND - male - 1521258 - Birmingham Phoenix vs London Spirit
2026-08-09 - club - HND - male - 1521257 - Sunrisers Leeds vs Welsh Fire
2026-08-09 - club - HND - female - 1521224 - London Spirit vs Birmingham Phoenix
2026-08-09 - club - HND - female - 1521223 - Welsh Fire vs Sunrisers Leeds
2026-08-08 - club - HND - male - 1521256 - Manchester Super Giants vs Southern Brave
2026-08-08 - club - HND - male - 1521255 - MI London vs Trent Rockets
2026-08-08 - club - HND - female - 1521222 - Manchester Super Giants vs Southern Brave
2026-08-08 - club - HND - female - 1521221 - MI London vs Trent Rockets
2026-08-07 - club - HND - male - 1521254 - Sunrisers Leeds vs Birmingham Phoenix
2026-08-07 - club - HND - female - 1521220 - Birmingham Phoenix vs Sunrisers Leeds
2026-08-06 - club - HND - male - 1521253 - London Spirit vs MI London
2026-08-06 - club - HND - female - 1521219 - MI London vs London Spirit
2026-08-05 - club - HND - male - 1521252 - Birmingham Phoenix vs Trent Rockets
2026-08-05 - club - HND - male - 1521251 - Welsh Fire vs Manchester Super Giants
2026-08-05 - club - HND - female - 1521218 - Birmingham Phoenix vs Trent Rockets
2026-08-05 - club - HND - female - 1521217 - Manchester Super Giants vs Welsh Fire
2026-08-04 - club - HND - male - 1521250 - Sunrisers Leeds vs London Spirit
2026-08-04 - club - HND - female - 1521216 - London Spirit vs Sunrisers Leeds
2026-08-03 - club - HND - male - 1521249 - Southern Brave vs Welsh Fire
2026-08-03 - club - HND - female - 1521215 - Southern Brave vs Welsh Fire
2026-08-02 - club - HND - male - 1521248 - MI London vs Manchester Super Giants
2026-08-02 - club - HND - male - 1521247 - Trent Rockets vs Sunrisers Leeds
2026-08-02 - club - HND - female - 1521214 - MI London vs Manchester Super Giants
2026-08-02 - club - HND - female - 1521213 - Trent Rockets vs Sunrisers Leeds
2026-08-01 - club - HND - male - 1521246 - London Spirit vs Southern Brave
2026-08-01 - club - HND - male - 1521245 - Birmingham Phoenix vs Welsh Fire
2026-08-01 - club - HND - female - 1521212 - London Spirit vs Southern Brave
2026-08-01 - club - HND - female - 1521211 - Welsh Fire vs Birmingham Phoenix
2026-07-31 - club - HND - male - 1521244 - Manchester Super Giants vs Trent Rockets
2026-07-31 - club - HND - female - 1521210 - Trent Rockets vs Manchester Super Giants
2026-07-30 - club - HND - male - 1521243 - Southern Brave vs Birmingham Phoenix
2026-07-30 - club - HND - female - 1521209 - Southern Brave vs Birmingham Phoenix
2026-07-29 - club - HND - male - 1521242 - MI London vs London Spirit
2026-07-29 - club - HND - male - 1521241 - Welsh Fire vs Trent Rockets
2026-07-29 - club - HND - female - 1521208 - MI London vs London Spirit
2026-07-29 - club - HND - female - 1521207 - Welsh Fire vs Trent Rockets
2026-07-28 - club - HND - male - 1521240 - Manchester Super Giants vs Sunrisers Leeds
2026-07-28 - club - HND - female - 1521206 - Sunrisers Leeds vs Manchester Super Giants
2026-07-27 - club - HND - male - 1521239 - Southern Brave vs MI London
2026-07-27 - club - HND - female - 1521205 - Southern Brave vs MI London
2026-07-26 - club - HND - male - 1521238 - London Spirit vs Trent Rockets
2026-07-26 - club - HND - male - 1521237 - Manchester Super Giants vs Birmingham Phoenix
2026-07-26 - club - HND - female - 1521204 - Trent Rockets vs London Spirit
2026-07-25 - club - HND - male - 1521236 - Welsh Fire vs MI London
2026-07-25 - club - HND - male - 1521235 - Sunrisers Leeds vs Southern Brave
2026-07-25 - club - HND - female - 1521202 - Welsh Fire vs MI London
2026-07-25 - club - HND - female - 1521201 - Sunrisers Leeds vs Southern Brave
2026-07-24 - club - HND - male - 1521234 - Birmingham Phoenix vs Trent Rockets
2026-07-24 - club - HND - female - 1521200 - Birmingham Phoenix vs Trent Rockets
2026-07-23 - club - HND - male - 1521233 - Manchester Super Giants vs London Spirit
2026-07-23 - club - HND - female - 1521199 - London Spirit vs Manchester Super Giants
2026-07-22 - club - HND - male - 1521232 - Southern Brave vs Welsh Fire
2026-07-22 - club - HND - female - 1521198 - Southern Brave vs Welsh Fire
2026-07-21 - club - HND - male - 1521231 - Sunrisers Leeds vs MI London
2026-07-21 - club - HND - female - 1521197 - MI London vs Sunrisers Leeds
2025-08-31 - club - HND - male - 1471035 - Oval Invincibles vs Trent Rockets
2025-08-31 - club - HND - female - 1471069 - Southern Brave vs Northern Superchargers
2025-08-30 - club - HND - male - 1471034 - Northern Superchargers vs Trent Rockets
2025-08-30 - club - HND - female - 1471068 - Northern Superchargers vs London Spirit
2025-08-28 - club - HND - male - 1471033 - Southern Brave vs Welsh Fire
2025-08-28 - club - HND - female - 1471067 - Southern Brave vs Welsh Fire
2025-08-27 - club - HND - male - 1471032 - Birmingham Phoenix vs Trent Rockets
2025-08-27 - club - HND - female - 1471066 - Birmingham Phoenix vs Trent Rockets
2025-08-26 - club - HND - male - 1471031 - Northern Superchargers vs Manchester Originals
2025-08-26 - club - HND - female - 1471065 - Manchester Originals vs Northern Superchargers
2025-08-25 - club - HND - male - 1471030 - London Spirit vs Oval Invincibles
2025-08-25 - club - HND - female - 1471064 - Oval Invincibles vs London Spirit
2025-08-24 - club - HND - male - 1471029 - Manchester Originals vs Birmingham Phoenix
2025-08-24 - club - HND - male - 1471028 - Welsh Fire vs Trent Rockets
2025-08-24 - club - HND - female - 1471063 - Birmingham Phoenix vs Manchester Originals
2025-08-24 - club - HND - female - 1471062 - Trent Rockets vs Welsh Fire
2025-08-23 - club - HND - male - 1471027 - London Spirit vs Southern Brave
2025-08-23 - club - HND - male - 1471026 - Northern Superchargers vs Oval Invincibles
2025-08-23 - club - HND - female - 1471061 - London Spirit vs Southern Brave
2025-08-23 - club - HND - female - 1471060 - Oval Invincibles vs Northern Superchargers
2025-08-22 - club - HND - male - 1471025 - Birmingham Phoenix vs Welsh Fire
2025-08-22 - club - HND - female - 1471059 - Welsh Fire vs Birmingham Phoenix
2025-08-21 - club - HND - male - 1471024 - Trent Rockets vs Oval Invincibles
2025-08-21 - club - HND - female - 1471058 - Oval Invincibles vs Trent Rockets
2025-08-20 - club - HND - male - 1471023 - London Spirit vs Northern Superchargers
2025-08-20 - club - HND - male - 1471022 - Southern Brave vs Welsh Fire
2025-08-20 - club - HND - female - 1471057 - London Spirit vs Northern Superchargers
2025-08-20 - club - HND - female - 1471056 - Welsh Fire vs Southern Brave
2025-08-19 - club - HND - male - 1471021 - Manchester Originals vs Trent Rockets
2025-08-19 - club - HND - female - 1471055 - Trent Rockets vs Manchester Originals
2025-08-18 - club - HND - male - 1471020 - Southern Brave vs Oval Invincibles
2025-08-18 - club - HND - female - 1471054 - Southern Brave vs Oval Invincibles
2025-08-17 - club - HND - male - 1471019 - London Spirit vs Birmingham Phoenix
2025-08-17 - club - HND - male - 1471018 - Manchester Originals vs Northern Superchargers
2025-08-17 - club - HND - female - 1471053 - London Spirit vs Birmingham Phoenix
2025-08-17 - club - HND - female - 1471052 - Manchester Originals vs Northern Superchargers
2025-08-16 - club - HND - male - 1471017 - Oval Invincibles vs Welsh Fire
2025-08-16 - club - HND - male - 1471016 - Southern Brave vs Trent Rockets
2025-08-16 - club - HND - female - 1471051 - Oval Invincibles vs Welsh Fire
2025-08-16 - club - HND - female - 1471050 - Trent Rockets vs Southern Brave
2025-08-15 - club - HND - male - 1471015 - Northern Superchargers vs Birmingham Phoenix
2025-08-15 - club - HND - female - 1471049 - Birmingham Phoenix vs Northern Superchargers
2025-08-14 - club - HND - male - 1471014 - London Spirit vs Trent Rockets
2025-08-14 - club - HND - female - 1471048 - Trent Rockets vs London Spirit
2025-08-13 - club - HND - male - 1471013 - Welsh Fire vs Manchester Originals
2025-08-13 - club - HND - male - 1471012 - Southern Brave vs Northern Superchargers
2025-08-13 - club - HND - female - 1471047 - Welsh Fire vs Manchester Originals
2025-08-13 - club - HND - female - 1471046 - Northern Superchargers vs Southern Brave
2025-08-12 - club - HND - male - 1471011 - Oval Invincibles vs Birmingham Phoenix
2025-08-12 - club - HND - female - 1471045 - Oval Invincibles vs Birmingham Phoenix
2025-08-11 - club - HND - male - 1471010 - Manchester Originals vs London Spirit
2025-08-11 - club - HND - female - 1471044 - Manchester Originals vs London Spirit
2025-08-10 - club - HND - male - 1471009 - Northern Superchargers vs Trent Rockets
2025-08-10 - club - HND - male - 1471008 - Birmingham Phoenix vs Southern Brave
2025-08-10 - club - HND - female - 1471043 - Trent Rockets vs Northern Superchargers
2025-08-10 - club - HND - female - 1471042 - Southern Brave vs Birmingham Phoenix
2025-08-09 - club - HND - male - 1471007 - London Spirit vs Welsh Fire
2025-08-09 - club - HND - male - 1471006 - Manchester Originals vs Oval Invincibles
2025-08-09 - club - HND - female - 1471041 - London Spirit vs Welsh Fire
2025-08-09 - club - HND - female - 1471040 - Manchester Originals vs Oval Invincibles
2025-08-08 - club - HND - male - 1471005 - Birmingham Phoenix vs Trent Rockets
2025-08-08 - club - HND - female - 1471039 - Birmingham Phoenix vs Trent Rockets
2025-08-07 - club - HND - male - 1471004 - Welsh Fire vs Northern Superchargers
2025-08-07 - club - HND - female - 1471038 - Northern Superchargers vs Welsh Fire
2025-08-06 - club - HND - male - 1471003 - Manchester Originals vs Southern Brave
2025-08-06 - club - HND - female - 1471037 - Manchester Originals vs Southern Brave
2025-08-05 - club - HND - male - 1471002 - London Spirit vs Oval Invincibles
2025-08-05 - club - HND - female - 1471036 - London Spirit vs Oval Invincibles
2024-08-18 - club - HND - male - 1417823 - Oval Invincibles vs Southern Brave
2024-08-18 - club - HND - female - 1417857 - Welsh Fire vs London Spirit
2024-08-17 - club - HND - male - 1417822 - Southern Brave vs Birmingham Phoenix
2024-08-17 - club - HND - female - 1417856 - Oval Invincibles vs London Spirit
2024-08-15 - club - HND - male - 1417821 - Manchester Originals vs Birmingham Phoenix
2024-08-15 - club - HND - female - 1417855 - Birmingham Phoenix vs Manchester Originals
2024-08-14 - club - HND - male - 1417820 - Oval Invincibles vs Trent Rockets
2024-08-14 - club - HND - male - 1417819 - Welsh Fire vs Southern Brave
2024-08-14 - club - HND - female - 1417854 - Trent Rockets vs Oval Invincibles
2024-08-14 - club - HND - female - 1417853 - Southern Brave vs Welsh Fire
2024-08-13 - club - HND - male - 1417818 - London Spirit vs Northern Superchargers
2024-08-13 - club - HND - female - 1417852 - Northern Superchargers vs London Spirit
2024-08-12 - club - HND - male - 1417817 - Trent Rockets vs Birmingham Phoenix
2024-08-12 - club - HND - female - 1417851 - Birmingham Phoenix vs Trent Rockets
2024-08-11 - club - HND - male - 1417816 - Manchester Originals vs Northern Superchargers
2024-08-11 - club - HND - male - 1417815 - London Spirit vs Oval Invincibles
2024-08-11 - club - HND - female - 1417850 - Manchester Originals vs Northern Superchargers
2024-08-11 - club - HND - female - 1417849 - London Spirit vs Oval Invincibles
2024-08-10 - club - HND - male - 1417814 - Welsh Fire vs Birmingham Phoenix
2024-08-10 - club - HND - male - 1417813 - Trent Rockets vs Southern Brave
2024-08-10 - club - HND - female - 1417848 - Birmingham Phoenix vs Welsh Fire
2024-08-10 - club - HND - female - 1417847 - Trent Rockets vs Southern Brave
2024-08-09 - club - HND - male - 1417812 - Manchester Originals vs London Spirit
2024-08-09 - club - HND - female - 1417846 - Manchester Originals vs London Spirit
2024-08-08 - club - HND - male - 1417811 - Southern Brave vs Oval Invincibles
2024-08-08 - club - HND - male - 1417810 - Northern Superchargers vs Welsh Fire
2024-08-08 - club - HND - female - 1417845 - Oval Invincibles vs Southern Brave
2024-08-07 - club - HND - male - 1417809 - Trent Rockets vs London Spirit
2024-08-07 - club - HND - female - 1417843 - Trent Rockets vs London Spirit
2024-08-06 - club - HND - male - 1417808 - Northern Superchargers vs Birmingham Phoenix
2024-08-06 - club - HND - male - 1417807 - Oval Invincibles vs Manchester Originals
2024-08-06 - club - HND - female - 1417842 - Northern Superchargers vs Birmingham Phoenix
2024-08-06 - club - HND - female - 1417841 - Manchester Originals vs Oval Invincibles
2024-08-05 - club - HND - male - 1417806 - Southern Brave vs Welsh Fire
2024-08-05 - club - HND - female - 1417840 - Southern Brave vs Welsh Fire
2024-08-04 - club - HND - male - 1417805 - Northern Superchargers vs Manchester Originals
2024-08-04 - club - HND - male - 1417804 - Oval Invincibles vs London Spirit
2024-08-04 - club - HND - female - 1417839 - Northern Superchargers vs Manchester Originals
2024-08-04 - club - HND - female - 1417838 - London Spirit vs Oval Invincibles
2024-08-03 - club - HND - male - 1417803 - Welsh Fire vs Trent Rockets
2024-08-03 - club - HND - male - 1417802 - Southern Brave vs Birmingham Phoenix
2024-08-03 - club - HND - female - 1417837 - Trent Rockets vs Welsh Fire
2024-08-03 - club - HND - female - 1417836 - Birmingham Phoenix vs Southern Brave
2024-08-02 - club - HND - male - 1417801 - Northern Superchargers vs Oval Invincibles
2024-08-02 - club - HND - female - 1417835 - Northern Superchargers vs Oval Invincibles
2024-08-01 - club - HND - male - 1417800 - Manchester Originals vs Southern Brave
2024-08-01 - club - HND - male - 1417799 - Welsh Fire vs London Spirit
2024-08-01 - club - HND - female - 1417834 - Southern Brave vs Manchester Originals
2024-08-01 - club - HND - female - 1417833 - London Spirit vs Welsh Fire
2024-07-31 - club - HND - male - 1417798 - Birmingham Phoenix vs Trent Rockets
2024-07-31 - club - HND - female - 1417832 - Birmingham Phoenix vs Trent Rockets
2024-07-30 - club - HND - male - 1417797 - Southern Brave vs Northern Superchargers
2024-07-30 - club - HND - female - 1417831 - Southern Brave vs Northern Superchargers
2024-07-29 - club - HND - male - 1417796 - Trent Rockets vs Manchester Originals
2024-07-29 - club - HND - female - 1417830 - Manchester Originals vs Trent Rockets
2024-07-28 - club - HND - male - 1417795 - Oval Invincibles vs Welsh Fire
2024-07-28 - club - HND - female - 1417829 - Welsh Fire vs Oval Invincibles
2024-07-27 - club - HND - male - 1417794 - London Spirit vs Birmingham Phoenix
2024-07-27 - club - HND - female - 1417828 - London Spirit vs Birmingham Phoenix
2024-07-26 - club - HND - male - 1417793 - Trent Rockets vs Northern Superchargers
2024-07-26 - club - HND - female - 1417827 - Trent Rockets vs Northern Superchargers
2024-07-25 - club - HND - male - 1417792 - Manchester Originals vs Welsh Fire
2024-07-25 - club - HND - female - 1417826 - Manchester Originals vs Welsh Fire
2024-07-24 - club - HND - male - 1417791 - London Spirit vs Southern Brave
2024-07-24 - club - HND - female - 1417825 - Southern Brave vs London Spirit
2024-07-23 - club - HND - male - 1417790 - Birmingham Phoenix vs Oval Invincibles
2024-07-23 - club - HND - female - 1417824 - Oval Invincibles vs Birmingham Phoenix
2023-08-27 - club - HND - male - 1355639 - Oval Invincibles vs Manchester Originals
2023-08-27 - club - HND - female - 1355605 - Southern Brave vs Northern Superchargers
2023-08-26 - club - HND - male - 1355638 - Southern Brave vs Manchester Originals
2023-08-26 - club - HND - female - 1355604 - Welsh Fire vs Northern Superchargers
2023-08-24 - club - HND - male - 1355637 - Birmingham Phoenix vs London Spirit
2023-08-24 - club - HND - female - 1355603 - London Spirit vs Birmingham Phoenix
2023-08-23 - club - HND - male - 1355636 - Manchester Originals vs Southern Brave
2023-08-23 - club - HND - female - 1355602 - Manchester Originals vs Southern Brave
2023-08-22 - club - HND - male - 1355635 - Northern Superchargers vs Welsh Fire
2023-08-22 - club - HND - female - 1355601 - Northern Superchargers vs Welsh Fire
2023-08-21 - club - HND - male - 1355634 - Trent Rockets vs Oval Invincibles
2023-08-21 - club - HND - female - 1355600 - Oval Invincibles vs Trent Rockets
2023-08-20 - club - HND - male - 1355633 - London Spirit vs Welsh Fire
2023-08-20 - club - HND - male - 1355632 - Manchester Originals vs Northern Superchargers
2023-08-20 - club - HND - female - 1355599 - Welsh Fire vs London Spirit
2023-08-20 - club - HND - female - 1355598 - Northern Superchargers vs Manchester Originals
2023-08-19 - club - HND - male - 1355631 - Oval Invincibles vs Southern Brave
2023-08-19 - club - HND - male - 1355630 - Trent Rockets vs Birmingham Phoenix
2023-08-19 - club - HND - female - 1355597 - Oval Invincibles vs Southern Brave
2023-08-19 - club - HND - female - 1355596 - Trent Rockets vs Birmingham Phoenix
2023-08-18 - club - HND - male - 1355629 - London Spirit vs Northern Superchargers
2023-08-18 - club - HND - female - 1355595 - London Spirit vs Northern Superchargers
2023-08-17 - club - HND - male - 1355628 - Manchester Originals vs Trent Rockets
2023-08-17 - club - HND - female - 1355594 - Manchester Originals vs Trent Rockets
2023-08-16 - club - HND - male - 1355627 - Birmingham Phoenix vs Southern Brave
2023-08-16 - club - HND - female - 1355593 - Southern Brave vs Birmingham Phoenix
2023-08-15 - club - HND - male - 1355626 - Oval Invincibles vs London Spirit
2023-08-15 - club - HND - female - 1355592 - London Spirit vs Oval Invincibles
2023-08-14 - club - HND - male - 1355625 - Trent Rockets vs Welsh Fire
2023-08-14 - club - HND - female - 1355591 - Welsh Fire vs Trent Rockets
2023-08-13 - club - HND - male - 1355624 - Birmingham Phoenix vs Oval Invincibles
2023-08-13 - club - HND - male - 1355623 - Manchester Originals vs Northern Superchargers
2023-08-13 - club - HND - female - 1355590 - Oval Invincibles vs Birmingham Phoenix
2023-08-13 - club - HND - female - 1355589 - Northern Superchargers vs Manchester Originals
2023-08-12 - club - HND - male - 1355622 - Welsh Fire vs Southern Brave
2023-08-12 - club - HND - male - 1355621 - London Spirit vs Trent Rockets
2023-08-12 - club - HND - female - 1355588 - Welsh Fire vs Southern Brave
2023-08-12 - club - HND - female - 1355587 - London Spirit vs Trent Rockets
2023-08-11 - club - HND - male - 1355620 - Oval Invincibles vs Northern Superchargers
2023-08-11 - club - HND - female - 1355586 - Northern Superchargers vs Oval Invincibles
2023-08-10 - club - HND - male - 1355619 - Birmingham Phoenix vs Welsh Fire
2023-08-10 - club - HND - female - 1355585 - Welsh Fire vs Birmingham Phoenix
2023-08-09 - club - HND - male - 1355618 - Oval Invincibles vs Manchester Originals
2023-08-09 - club - HND - male - 1355617 - Northern Superchargers vs Trent Rockets
2023-08-09 - club - HND - female - 1355584 - Oval Invincibles vs Manchester Originals
2023-08-09 - club - HND - female - 1355583 - Northern Superchargers vs Trent Rockets
2023-08-08 - club - HND - male - 1355616 - Southern Brave vs London Spirit
2023-08-08 - club - HND - female - 1355582 - London Spirit vs Southern Brave
2023-08-07 - club - HND - male - 1355615 - Manchester Originals vs Birmingham Phoenix
2023-08-07 - club - HND - female - 1355581 - Birmingham Phoenix vs Manchester Originals
2023-08-06 - club - HND - male - 1355614 - Welsh Fire vs Oval Invincibles
2023-08-06 - club - HND - male - 1355613 - Northern Superchargers vs Southern Brave
2023-08-06 - club - HND - female - 1355580 - Oval Invincibles vs Welsh Fire
2023-08-06 - club - HND - female - 1355579 - Northern Superchargers vs Southern Brave
2023-08-05 - club - HND - male - 1355611 - Manchester Originals vs London Spirit
2023-08-04 - club - HND - male - 1355610 - Southern Brave vs Welsh Fire
2023-08-04 - club - HND - female - 1355576 - Welsh Fire vs Southern Brave
2023-08-03 - club - HND - male - 1355609 - Birmingham Phoenix vs Northern Superchargers
2023-08-03 - club - HND - female - 1355575 - Birmingham Phoenix vs Northern Superchargers
2023-08-02 - club - HND - male - 1355608 - London Spirit vs Oval Invincibles
2023-08-02 - club - HND - male - 1355607 - Welsh Fire vs Manchester Originals
2023-08-01 - club - HND - male - 1355606 - Trent Rockets vs Southern Brave
2023-08-01 - club - HND - female - 1355572 - Southern Brave vs Trent Rockets
2022-09-03 - club - HND - male - 1299204 - Manchester Originals vs Trent Rockets
2022-09-03 - club - HND - female - 1299170 - Southern Brave vs Oval Invincibles
2022-09-02 - club - HND - male - 1299203 - London Spirit vs Manchester Originals
2022-09-02 - club - HND - female - 1299169 - Southern Brave vs Trent Rockets
2022-08-31 - club - HND - male - 1299202 - Oval Invincibles vs Manchester Originals
2022-08-31 - club - HND - male - 1299201 - Northern Superchargers vs Southern Brave
2022-08-31 - club - HND - female - 1299168 - Oval Invincibles vs Manchester Originals
2022-08-31 - club - HND - female - 1299167 - Northern Superchargers vs Southern Brave
2022-08-30 - club - HND - male - 1299200 - London Spirit vs Birmingham Phoenix
2022-08-30 - club - HND - female - 1299166 - Birmingham Phoenix vs London Spirit
2022-08-29 - club - HND - male - 1299199 - Trent Rockets vs Welsh Fire
2022-08-29 - club - HND - female - 1299165 - Welsh Fire vs Trent Rockets
2022-08-28 - club - HND - male - 1299198 - Manchester Originals vs Birmingham Phoenix
2022-08-28 - club - HND - female - 1299164 - Manchester Originals vs Birmingham Phoenix
2022-08-27 - club - HND - male - 1299197 - London Spirit vs Oval Invincibles
2022-08-27 - club - HND - female - 1299163 - London Spirit vs Oval Invincibles
2022-08-26 - club - HND - male - 1299196 - Welsh Fire vs Northern Superchargers
2022-08-26 - club - HND - female - 1299162 - Welsh Fire vs Northern Superchargers
2022-08-25 - club - HND - male - 1299195 - Trent Rockets vs Southern Brave
2022-08-25 - club - HND - female - 1299161 - Trent Rockets vs Southern Brave
2022-08-24 - club - HND - male - 1299194 - London Spirit vs Welsh Fire
2022-08-24 - club - HND - female - 1299160 - Welsh Fire vs London Spirit
2022-08-23 - club - HND - male - 1299193 - Birmingham Phoenix vs Oval Invincibles
2022-08-23 - club - HND - female - 1299159 - Birmingham Phoenix vs Oval Invincibles
2022-08-22 - club - HND - male - 1299192 - Welsh Fire vs Southern Brave
2022-08-22 - club - HND - female - 1299158 - Southern Brave vs Welsh Fire
2022-08-21 - club - HND - male - 1299191 - Manchester Originals vs Northern Superchargers
2022-08-21 - club - HND - female - 1299157 - Manchester Originals vs Northern Superchargers
2022-08-20 - club - HND - male - 1299190 - London Spirit vs Trent Rockets
2022-08-20 - club - HND - female - 1299156 - Trent Rockets vs London Spirit
2022-08-19 - club - HND - male - 1299189 - Northern Superchargers vs Birmingham Phoenix
2022-08-19 - club - HND - female - 1299155 - Birmingham Phoenix vs Northern Superchargers
2022-08-18 - club - HND - male - 1299188 - Manchester Originals vs Southern Brave
2022-08-18 - club - HND - female - 1299154 - Southern Brave vs Manchester Originals
2022-08-17 - club - HND - male - 1299187 - Trent Rockets vs Oval Invincibles
2022-08-17 - club - HND - female - 1299153 - Trent Rockets vs Oval Invincibles
2022-08-16 - club - HND - male - 1299186 - Manchester Originals vs Welsh Fire
2022-08-16 - club - HND - female - 1299152 - Manchester Originals vs Welsh Fire
2022-08-15 - club - HND - male - 1299185 - Trent Rockets vs Birmingham Phoenix
2022-08-15 - club - HND - female - 1299151 - Trent Rockets vs Birmingham Phoenix
2022-08-14 - club - HND - male - 1299184 - Southern Brave vs Oval Invincibles
2022-08-14 - club - HND - male - 1299183 - Northern Superchargers vs London Spirit
2022-08-14 - club - HND - female - 1299150 - Southern Brave vs Oval Invincibles
2022-08-14 - club - HND - female - 1299149 - Northern Superchargers vs London Spirit
2022-08-13 - club - HND - male - 1299182 - Birmingham Phoenix vs Welsh Fire
2022-08-13 - club - HND - male - 1299181 - Manchester Originals vs Trent Rockets
2022-08-13 - club - HND - female - 1299148 - Birmingham Phoenix vs Welsh Fire
2022-08-13 - club - HND - female - 1299147 - Trent Rockets vs Manchester Originals
2022-08-12 - club - HND - male - 1299180 - London Spirit vs Southern Brave
2022-08-12 - club - HND - female - 1299146 - London Spirit vs Southern Brave
2022-08-11 - club - HND - male - 1299179 - Northern Superchargers vs Oval Invincibles
2022-08-11 - club - HND - female - 1299145 - Northern Superchargers vs Oval Invincibles
2022-08-10 - club - HND - male - 1299178 - Birmingham Phoenix vs Southern Brave
2022-08-09 - club - HND - male - 1299177 - Northern Superchargers vs Trent Rockets
2022-08-08 - club - HND - male - 1299176 - London Spirit vs Manchester Originals
2022-08-07 - club - HND - male - 1299175 - Oval Invincibles vs Welsh Fire
2022-08-06 - club - HND - male - 1299174 - Birmingham Phoenix vs Trent Rockets
2022-08-05 - club - HND - male - 1299173 - Manchester Originals vs Northern Superchargers
2022-08-04 - club - HND - male - 1299172 - London Spirit vs Oval Invincibles
2022-08-03 - club - HND - male - 1299171 - Welsh Fire vs Southern Brave
2021-08-21 - club - HND - male - 1252699 - Southern Brave vs Birmingham Phoenix
2021-08-21 - club - HND - female - 1252733 - Oval Invincibles vs Southern Brave
2021-08-20 - club - HND - male - 1252698 - Trent Rockets vs Southern Brave
2021-08-20 - club - HND - female - 1252732 - Oval Invincibles vs Birmingham Phoenix
2021-08-18 - club - HND - male - 1252697 - London Spirit vs Welsh Fire
2021-08-18 - club - HND - female - 1252731 - Welsh Fire vs London Spirit
2021-08-17 - club - HND - male - 1252696 - Northern Superchargers vs Birmingham Phoenix
2021-08-17 - club - HND - female - 1252730 - Birmingham Phoenix vs Northern Superchargers
2021-08-16 - club - HND - male - 1252695 - Oval Invincibles vs Southern Brave
2021-08-16 - club - HND - female - 1252729 - Southern Brave vs Oval Invincibles
2021-08-15 - club - HND - male - 1252694 - Manchester Originals vs Trent Rockets
2021-08-15 - club - HND - female - 1252728 - Trent Rockets vs Manchester Originals
2021-08-14 - club - HND - male - 1252693 - London Spirit vs Oval Invincibles
2021-08-14 - club - HND - female - 1252727 - London Spirit vs Oval Invincibles
2021-08-13 - club - HND - male - 1252692 - Birmingham Phoenix vs Trent Rockets
2021-08-13 - club - HND - female - 1252726 - Trent Rockets vs Birmingham Phoenix
2021-08-12 - club - HND - male - 1252691 - Northern Superchargers vs Manchester Originals
2021-08-12 - club - HND - female - 1252725 - Northern Superchargers vs Manchester Originals
2021-08-11 - club - HND - male - 1252690 - Welsh Fire vs Southern Brave
2021-08-11 - club - HND - female - 1252724 - Southern Brave vs Welsh Fire
2021-08-10 - club - HND - male - 1252689 - London Spirit vs Manchester Originals
2021-08-10 - club - HND - female - 1252723 - Manchester Originals vs London Spirit
2021-08-09 - club - HND - male - 1252688 - Birmingham Phoenix vs Welsh Fire
2021-08-09 - club - HND - female - 1252722 - Welsh Fire vs Birmingham Phoenix
2021-08-08 - club - HND - male - 1252687 - Oval Invincibles vs Trent Rockets
2021-08-07 - club - HND - male - 1252686 - Northern Superchargers vs Southern Brave
2021-08-07 - club - HND - female - 1252720 - Northern Superchargers vs Southern Brave
2021-08-06 - club - HND - male - 1252685 - Welsh Fire vs Trent Rockets
2021-08-06 - club - HND - female - 1252719 - Welsh Fire vs Trent Rockets
2021-08-05 - club - HND - male - 1252684 - Manchester Originals vs Southern Brave
2021-08-05 - club - HND - female - 1252718 - Southern Brave vs Manchester Originals
2021-08-04 - club - HND - male - 1252683 - Oval Invincibles vs Birmingham Phoenix
2021-08-04 - club - HND - female - 1252717 - Birmingham Phoenix vs Oval Invincibles
2021-08-03 - club - HND - male - 1252682 - Northern Superchargers vs London Spirit
2021-08-03 - club - HND - female - 1252716 - Northern Superchargers vs London Spirit
2021-08-02 - club - HND - male - 1252681 - Welsh Fire vs Oval Invincibles
2021-08-02 - club - HND - female - 1252715 - Welsh Fire vs Oval Invincibles
2021-08-01 - club - HND - male - 1252680 - Southern Brave vs London Spirit
2021-08-01 - club - HND - male - 1252679 - Trent Rockets vs Birmingham Phoenix
2021-08-01 - club - HND - female - 1252714 - London Spirit vs Southern Brave
2021-08-01 - club - HND - female - 1252713 - Trent Rockets vs Birmingham Phoenix
2021-07-31 - club - HND - male - 1252678 - Oval Invincibles vs Northern Superchargers
2021-07-31 - club - HND - male - 1252677 - Welsh Fire vs Manchester Originals
2021-07-31 - club - HND - female - 1252712 - Northern Superchargers vs Oval Invincibles
2021-07-31 - club - HND - female - 1252711 - Manchester Originals vs Welsh Fire
2021-07-30 - club - HND - male - 1252676 - Birmingham Phoenix vs Southern Brave
2021-07-30 - club - HND - female - 1252710 - Birmingham Phoenix vs Southern Brave
2021-07-29 - club - HND - male - 1252675 - Trent Rockets vs London Spirit
2021-07-29 - club - HND - female - 1252709 - Trent Rockets vs London Spirit
2021-07-27 - club - HND - male - 1252673 - Welsh Fire vs Southern Brave
2021-07-27 - club - HND - female - 1252707 - Welsh Fire vs Southern Brave
2021-07-26 - club - HND - male - 1252672 - Northern Superchargers vs Trent Rockets
2021-07-26 - club - HND - female - 1252706 - Northern Superchargers vs Trent Rockets
2021-07-25 - club - HND - male - 1252671 - Birmingham Phoenix vs Manchester Originals
2021-07-25 - club - HND - female - 1252705 - Birmingham Phoenix vs Manchester Originals
2021-07-25 - club - HND - female - 1252704 - Oval Invincibles vs London Spirit
2021-07-24 - club - HND - male - 1252669 - Welsh Fire vs Northern Superchargers
2021-07-24 - club - HND - male - 1252668 - Southern Brave vs Trent Rockets
2021-07-24 - club - HND - female - 1252703 - Welsh Fire vs Northern Superchargers
2021-07-24 - club - HND - female - 1252702 - Southern Brave vs Trent Rockets
2021-07-23 - club - HND - male - 1252667 - London Spirit vs Birmingham Phoenix
2021-07-23 - club - HND - female - 1252701 - Birmingham Phoenix vs London Spirit
2021-07-22 - club - HND - male - 1252666 - Oval Invincibles vs Manchester Originals
2021-07-21 - club - HND - female - 1252700 - Manchester Originals vs Oval Invincibles

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk

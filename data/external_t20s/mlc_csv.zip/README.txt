All Major League Cricket match data in CSV format
=================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All Major League Cricket matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.9.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2026-07-18 - club - MLC - male - 1528590 - Los Angeles Knight Riders vs Washington Freedom
2026-07-16 - club - MLC - male - 1528589 - Washington Freedom vs San Francisco Unicorns
2026-07-15 - club - MLC - male - 1528588 - MI New York vs Washington Freedom
2026-07-15 - club - MLC - male - 1528587 - Los Angeles Knight Riders vs San Francisco Unicorns
2026-07-12 - club - MLC - male - 1528586 - Texas Super Kings vs Los Angeles Knight Riders
2026-07-12 - club - MLC - male - 1528585 - MI New York vs Washington Freedom
2026-07-11 - club - MLC - male - 1528584 - Seattle Orcas vs San Francisco Unicorns
2026-07-11 - club - MLC - male - 1528583 - Texas Super Kings vs Washington Freedom
2026-07-10 - club - MLC - male - 1528582 - Los Angeles Knight Riders vs San Francisco Unicorns
2026-07-10 - club - MLC - male - 1528581 - MI New York vs Seattle Orcas
2026-07-09 - club - MLC - male - 1528580 - Los Angeles Knight Riders vs Washington Freedom
2026-07-08 - club - MLC - male - 1528579 - MI New York vs San Francisco Unicorns
2026-07-05 - club - MLC - male - 1528578 - MI New York vs San Francisco Unicorns
2026-07-05 - club - MLC - male - 1528577 - Seattle Orcas vs Texas Super Kings
2026-07-04 - club - MLC - male - 1528576 - Los Angeles Knight Riders vs MI New York
2026-07-04 - club - MLC - male - 1528575 - San Francisco Unicorns vs Washington Freedom
2026-07-03 - club - MLC - male - 1528574 - Texas Super Kings vs Los Angeles Knight Riders
2026-07-02 - club - MLC - male - 1528573 - MI New York vs Seattle Orcas
2026-07-01 - club - MLC - male - 1528572 - Los Angeles Knight Riders vs Washington Freedom
2026-06-28 - club - MLC - male - 1528571 - Washington Freedom vs San Francisco Unicorns
2026-06-28 - club - MLC - male - 1528570 - Seattle Orcas vs Los Angeles Knight Riders
2026-06-27 - club - MLC - male - 1528569 - Texas Super Kings vs Washington Freedom
2026-06-27 - club - MLC - male - 1528568 - MI New York vs Los Angeles Knight Riders
2026-06-26 - club - MLC - male - 1528567 - Seattle Orcas vs San Francisco Unicorns
2026-06-26 - club - MLC - male - 1528566 - MI New York vs Texas Super Kings
2026-06-25 - club - MLC - male - 1528565 - Seattle Orcas vs Washington Freedom
2026-06-24 - club - MLC - male - 1528564 - Texas Super Kings vs San Francisco Unicorns
2026-06-21 - club - MLC - male - 1528563 - Texas Super Kings vs MI New York
2026-06-21 - club - MLC - male - 1528562 - Los Angeles Knight Riders vs Seattle Orcas
2026-06-20 - club - MLC - male - 1528561 - Washington Freedom vs MI New York
2026-06-20 - club - MLC - male - 1528560 - Texas Super Kings vs San Francisco Unicorns
2026-06-19 - club - MLC - male - 1528559 - Washington Freedom vs Seattle Orcas
2026-06-19 - club - MLC - male - 1528558 - San Francisco Unicorns vs Los Angeles Knight Riders
2026-06-18 - club - MLC - male - 1528557 - Seattle Orcas vs Texas Super Kings
2025-07-13 - club - MLC - male - 1482025 - MI New York vs Washington Freedom
2025-07-11 - club - MLC - male - 1482024 - Texas Super Kings vs MI New York
2025-07-09 - club - MLC - male - 1482023 - San Francisco Unicorns vs MI New York
2025-07-06 - club - MLC - male - 1482021 - Los Angeles Knight Riders vs San Francisco Unicorns
2025-07-06 - club - MLC - male - 1482020 - MI New York vs Washington Freedom
2025-07-05 - club - MLC - male - 1482019 - Texas Super Kings vs Seattle Orcas
2025-07-05 - club - MLC - male - 1482018 - MI New York vs Los Angeles Knight Riders
2025-07-04 - club - MLC - male - 1482017 - Seattle Orcas vs Washington Freedom
2025-07-04 - club - MLC - male - 1482016 - San Francisco Unicorns vs Texas Super Kings
2025-07-03 - club - MLC - male - 1482015 - Los Angeles Knight Riders vs MI New York
2025-07-02 - club - MLC - male - 1482014 - Texas Super Kings vs Washington Freedom
2025-07-01 - club - MLC - male - 1482013 - San Francisco Unicorns vs Seattle Orcas
2025-06-29 - club - MLC - male - 1482012 - Texas Super Kings vs MI New York
2025-06-28 - club - MLC - male - 1482011 - Los Angeles Knight Riders vs Seattle Orcas
2025-06-28 - club - MLC - male - 1482010 - Washington Freedom vs San Francisco Unicorns
2025-06-27 - club - MLC - male - 1482009 - MI New York vs Seattle Orcas
2025-06-26 - club - MLC - male - 1482008 - Los Angeles Knight Riders vs Washington Freedom
2025-06-25 - club - MLC - male - 1482007 - San Francisco Unicorns vs Seattle Orcas
2025-06-24 - club - MLC - male - 1482006 - Texas Super Kings vs Los Angeles Knight Riders
2025-06-23 - club - MLC - male - 1482005 - San Francisco Unicorns vs MI New York
2025-06-22 - club - MLC - male - 1482004 - Texas Super Kings vs Washington Freedom
2025-06-22 - club - MLC - male - 1482003 - Seattle Orcas vs Los Angeles Knight Riders
2025-06-21 - club - MLC - male - 1482002 - MI New York vs Washington Freedom
2025-06-20 - club - MLC - male - 1482001 - Texas Super Kings vs San Francisco Unicorns
2025-06-18 - club - MLC - male - 1482000 - Seattle Orcas vs MI New York
2025-06-17 - club - MLC - male - 1481999 - Washington Freedom vs Los Angeles Knight Riders
2025-06-16 - club - MLC - male - 1481998 - Texas Super Kings vs Seattle Orcas
2025-06-15 - club - MLC - male - 1481997 - MI New York vs San Francisco Unicorns
2025-06-15 - club - MLC - male - 1481996 - Texas Super Kings vs Los Angeles Knight Riders
2025-06-14 - club - MLC - male - 1481995 - Seattle Orcas vs Washington Freedom
2025-06-14 - club - MLC - male - 1481994 - San Francisco Unicorns vs Los Angeles Knight Riders
2025-06-13 - club - MLC - male - 1481993 - Texas Super Kings vs MI New York
2025-06-12 - club - MLC - male - 1481992 - San Francisco Unicorns vs Washington Freedom
2024-07-28 - club - MLC - male - 1432750 - Washington Freedom vs San Francisco Unicorns
2024-07-26 - club - MLC - male - 1432749 - San Francisco Unicorns vs Texas Super Kings
2024-07-25 - club - MLC - male - 1432748 - San Francisco Unicorns vs Washington Freedom
2024-07-24 - club - MLC - male - 1432747 - MI New York vs Texas Super Kings
2024-07-23 - club - MLC - male - 1432746 - Texas Super Kings vs Seattle Orcas
2024-07-22 - club - MLC - male - 1432745 - Washington Freedom vs San Francisco Unicorns
2024-07-21 - club - MLC - male - 1432744 - Los Angeles Knight Riders vs MI New York
2024-07-20 - club - MLC - male - 1432743 - Seattle Orcas vs San Francisco Unicorns
2024-07-19 - club - MLC - male - 1432742 - Washington Freedom vs Texas Super Kings
2024-07-18 - club - MLC - male - 1432741 - San Francisco Unicorns vs MI New York
2024-07-17 - club - MLC - male - 1432740 - Seattle Orcas vs Los Angeles Knight Riders
2024-07-16 - club - MLC - male - 1432739 - Washington Freedom vs MI New York
2024-07-15 - club - MLC - male - 1432738 - San Francisco Unicorns vs Seattle Orcas
2024-07-14 - club - MLC - male - 1432737 - Texas Super Kings vs MI New York
2024-07-14 - club - MLC - male - 1432736 - Los Angeles Knight Riders vs Washington Freedom
2024-07-11 - club - MLC - male - 1432733 - Seattle Orcas vs Washington Freedom
2024-07-10 - club - MLC - male - 1432732 - San Francisco Unicorns vs Texas Super Kings
2024-07-09 - club - MLC - male - 1432731 - Los Angeles Knight Riders vs Seattle Orcas
2024-07-08 - club - MLC - male - 1432730 - Texas Super Kings vs Washington Freedom
2024-07-07 - club - MLC - male - 1432729 - Los Angeles Knight Riders vs San Francisco Unicorns
2024-07-06 - club - MLC - male - 1432728 - MI New York vs Washington Freedom
2024-07-05 - club - MLC - male - 1432727 - Los Angeles Knight Riders vs Texas Super Kings
2024-07-05 - club - MLC - male - 1432726 - Seattle Orcas vs MI New York
2023-07-30 - club - MLC - male - 1381379 - Seattle Orcas vs MI New York
2023-07-28 - club - MLC - male - 1381378 - Texas Super Kings vs MI New York
2023-07-27 - club - MLC - male - 1381377 - Texas Super Kings vs Seattle Orcas
2023-07-27 - club - MLC - male - 1381376 - MI New York vs Washington Freedom
2023-07-25 - club - MLC - male - 1381375 - MI New York vs Seattle Orcas
2023-07-24 - club - MLC - male - 1381374 - San Francisco Unicorns vs Texas Super Kings
2023-07-23 - club - MLC - male - 1381373 - Washington Freedom vs MI New York
2023-07-23 - club - MLC - male - 1381372 - Seattle Orcas vs Los Angeles Knight Riders
2023-07-22 - club - MLC - male - 1381371 - Washington Freedom vs San Francisco Unicorns
2023-07-21 - club - MLC - male - 1381370 - Texas Super Kings vs Seattle Orcas
2023-07-20 - club - MLC - male - 1381369 - Los Angeles Knight Riders vs Washington Freedom
2023-07-18 - club - MLC - male - 1381368 - San Francisco Unicorns vs Los Angeles Knight Riders
2023-07-17 - club - MLC - male - 1381367 - Texas Super Kings vs MI New York
2023-07-16 - club - MLC - male - 1381366 - MI New York vs Los Angeles Knight Riders
2023-07-16 - club - MLC - male - 1381365 - Washington Freedom vs Texas Super Kings
2023-07-15 - club - MLC - male - 1381364 - Seattle Orcas vs San Francisco Unicorns
2023-07-14 - club - MLC - male - 1381363 - Washington Freedom vs Seattle Orcas
2023-07-14 - club - MLC - male - 1381362 - San Francisco Unicorns vs MI New York
2023-07-13 - club - MLC - male - 1381361 - Texas Super Kings vs Los Angeles Knight Riders

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
